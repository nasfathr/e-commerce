import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipt',
  templateUrl: './recipt.component.html',
  styleUrls: ['./recipt.component.css']
})
export class ReciptComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
